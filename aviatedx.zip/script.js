
const crashPointDisplay = document.getElementById('crashPoint');
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let crashPoint = (Math.random() * 10).toFixed(2);
crashPointDisplay.innerText = `Crash Point: ${crashPoint}x`;

function drawPlane() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#00ffcc";
    ctx.fillRect(Math.random() * canvas.width, 100, 100, 30); // simulate plane
}
setInterval(drawPlane, 1000);
