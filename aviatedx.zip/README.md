# AviatedX 🚀

**AviatedX** is a futuristic AI-style simulation of the popular "Aviator" game concept. 
Built for entertainment and concept demonstration purposes only.

## Features
- ✈️ Futuristic UI with B-2 Spirit plane
- 🎮 Simulated crash-point logic
- 🔊 Sound effects and smooth UI transitions
- 📲 Telegram and demo call-to-actions

## Live Demo
[Click to Launch AviatedX](https://oyierdalmas94.github.io/dcc-smart-bot/)

## Connect
Join the community: [Telegram Bot](http://t.me/Oyiersbot)

---

**Note:** This is a front-end simulation, not a real-money trading platform.
