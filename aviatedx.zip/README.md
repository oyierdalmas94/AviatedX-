
# AviateDX

A simple browser-based flight simulation game. Control your B-2 Spirit and soar through the skies.

## Features

- Keyboard controls for flying
- Background music and effects
- Telegram integration button

## How to Run

1. Download or clone the repository.
2. Open `index.html` in a browser.
3. Enjoy!

## License

MIT
    